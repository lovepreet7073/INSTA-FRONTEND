import React, { useState } from 'react';
import Stories from 'react-insta-stories';
import formatShortDate from '../functions/formatDate';
import { useSelector } from 'react-redux';


const ViewStoryModal = ({ viewStory, handleStoryViewModal, stories, profileImage, username, viewers }) => {
  const [viewersModal, setViewersModal] = useState(false);
  const userData = useSelector((state) => state.user.userData);

  const storyItems = stories && stories.map(storyItem => ({
    url: `http://localhost:5000/images/${storyItem.image.filename}`,
    header: {
      heading: username,
      subheading: `${formatShortDate(storyItem.createdAt)}`,
      profileImage: `http://localhost:5000/images/${profileImage}`,
    }

  }))

  const handleViewersModal = () => {
    setViewersModal(!viewersModal);
  };


  const isStoryCreator = userData._id === stories[0]?.postedBy?._id;
  console.log('Story data:', stories);
  console.log('Viewers:', viewers);
  return (
    <div>
      {viewStory && (
        <div className={`modal fade ${viewStory ? 'show' : ''}`} style={{ display: viewStory ? 'block' : 'none' }} tabIndex="-1" role="dialog">
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-body">
                <button type="button" className="btn-close" onClick={handleStoryViewModal}></button>

                {storyItems && storyItems.length > 0 ? (
                  <span>
                    <Stories
                      stories={storyItems}
                      defaultInterval={5000}
                      width={470}
                      height={500}
                      loop
                      onStoryStart={(index) => console.log(`Story ${index} started`)}
                      onStoryChange={(index) => console.log(`Story changed to ${index}`)}
                    />
                    {isStoryCreator && (
                      <i className="bi bi-eye" style={{ cursor: 'pointer', position: "absolute" }} onClick={handleViewersModal}></i>
                    )}
                  </span>
                ) : (
                  <p>No stories available</p> // Optional message if there are no stories
                )}
              </div>

            </div>
          </div>
        </div>
      )}
      {viewStory && <div className="modal-backdrop fade show" onClick={handleStoryViewModal}></div>}
      {viewersModal && (
        <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1" role="dialog">
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Viewers</h5>
                <button type="button" className="btn-close" onClick={handleViewersModal}></button>
              </div>
              <div className="modal-body">
                {viewers.length > 0 ? (
                  <ul className="list-group">
                    {viewers.map((viewer, index) => (
                      {viewer._id !== }
                      <li className="list-group-item" key={index}>
                        <img
                          src={`http://localhost:5000/images/${viewer.profileImage}`}
                          alt={viewer.username}
                          className="rounded-circle"
                          style={{ width: '30px', height: '30px', marginRight: '10px' }}
                        />
                        {viewer.name}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p>No viewers yet</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
      {viewersModal && <div className="modal-backdrop fade show" onClick={handleViewersModal}></div>}
    </div>
  );
};

export default ViewStoryModal;
